import * as React from 'react';
import { Scroll } from 'framer';

const style: React.CSSProperties = {
  color: '#8855FF',
  background: 'rgba(136, 85, 255, 0.1)'
};

export class Sticky extends React.Component<Props> {
  state = {
    scrollY: 0,
    lastTop: 0
  };

  handleScroll = e => {
    this.setState({ scrollY: -e.y });
  };

  cloneAndOffsetStickyFramesElements = (elements = []) =>
    elements.map(e => {
      const { componentIdentifier } = e.props;

      if (
        componentIdentifier &&
        componentIdentifier.includes('StickyElement')
      ) {
        let offset =
          (e.props.children[0] && e.props.children[0].props.offset) || 0;

        if (this.state.scrollY > e.props.top - offset) {
          if (this.state.lastTop < e.props.top) {
            this.setState({ lastTop: e.props.top });
          }

          if (
            this.state.scrollY < this.state.lastTop ||
            e.props.top >= this.state.lastTop
          ) {
            if (e.props.top < this.state.lastTop) {
              this.setState({ lastTop: 0 });
            }

            return this.cloneAndOffsetStickyFrames(e, {
              top: this.state.scrollY
            });
          }
        }

        return this.cloneAndOffsetStickyFrames(e);
      } else {
        return this.cloneAndOffsetStickyFrames(e);
      }
    });

  cloneAndOffsetStickyFrames = (e, props = null) =>
    React.cloneElement(
      e,
      props,
      this.cloneAndOffsetStickyFramesElements(e.props.children)
    );

  static defaultProps = { ...Scroll.defaultProps };
  static propertyControls = { ...Scroll.propertyControls };

  render() {
    const rootElement = this.props.children[0];

    let content;

    if (rootElement) {
      content = this.cloneAndOffsetStickyFrames(rootElement);
    } else {
      content = 'Connect to a scroll content frame →';
    }

    return (
      <Scroll {...this.props} style={style} onMove={this.handleScroll}>
        {content}
      </Scroll>
    );
  }
}
