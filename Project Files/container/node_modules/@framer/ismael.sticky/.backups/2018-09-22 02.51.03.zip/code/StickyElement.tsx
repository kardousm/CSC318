import * as React from 'react';
import { PropertyControls, ControlType } from 'framer';

const style: React.CSSProperties = {
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: '#8855FF',
  background: 'rgba(136, 85, 255, 0.1)',
  overflow: 'hidden'
};

interface Props {
  offset: number;
}

export class StickyElement extends React.Component {
  static defaultProps = {
    offset: 0
  };

  static propertyControls: PropertyControls<Props> = {
    offset: {
      type: ControlType.Number,
      title: 'Offset',
      min: -500,
      max: 500
    }
  };

  render() {
    const { children } = this.props;
    let content;
    let contentStyle = style;

    if (children.length <= 0) {
      content = 'Connect to a sticky element →';
    } else {
      content = children;
      contentStyle = { ...style, background: null };
    }

    return <div style={contentStyle}>{content}</div>;
  }
}
