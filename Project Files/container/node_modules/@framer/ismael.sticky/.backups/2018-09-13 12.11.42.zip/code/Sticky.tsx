import * as React from "react";
import { PropertyControls, ControlType, Override, Data, Frame } from "framer";

const app = Data({
    scrollPosition: 0, /* posicion vertical del scroll */
    // elementHeight: 0, /* altura original del elemento sticky */
    // elementTopPosition: 0, /* posicion original del elemento sticky */
    // isFixed: false,
    // elements: [], /* guardo todos los sticky que pueda haber */
    // elementTopPositions: [],
    lastTop: 0
});

// function isInArray(arr, el) {
//     return arr.find((o) => {
//         return o.id === el.id;
//     });
// }

/* Apply getData override to Sticky component (this one) */
export const getData: Override = props => {
    if (!props.top) return;

    // console.log(props);
    let offset = 0;
    if (props.children && props.children[0].props.offset) {
        offset = props.children[0].props.offset;
    }

    if (app.scrollPosition > props.top + offset) {
        // console.log({scroll: app.scrollPosition, top: props.top, lastTop: app.lastTop});

        if (app.lastTop < props.top) {
            app.lastTop = props.top;
        }

        /* cuando vuelvo arriba */
        if (app.scrollPosition < app.lastTop) {/* - props.height */
            if (props.top < app.lastTop - props.height) {
                app.lastTop = 0;

                return {
                    top: props.top
                }
            }
        }

        if (props.top < app.lastTop) {
            return {
                top: props.top
            }
        } else {
            return {
                top: app.scrollPosition
            }
        }
    }
};

/* Apply scrollComponent override to Scroll component (from FramerX) */
export const scrollComponent: Override = props => {
    return {
        onMove: point => {
            // let scrollTop = -point.y;
            // app.scrollPosition = scrollTop;
            app.scrollPosition = -point.y;

            // if (scrollTop > app.elementTopPosition) {
            //     if (!app.isFixed) {
            //         app.isFixed = true;
            //     }
            // } else {
            //     if (app.isFixed) {
            //         app.isFixed = false;
            //     }
            // }
        }
    };
};

const noChildrenStyle: React.CSSProperties = {
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    color: "#8855FF",
    background: "rgba(136, 85, 255, 0.1)",
    overflow: "hidden",
    fontSize: 12
};

// Define type of property
interface Props {
    offset: number;
}

export class Sticky extends React.Component<Props> {
    state = {
        isFixed: false
    }

    // Set default properties
    static defaultProps = {
        offset: 0
    }

    // Items shown in property panel
    static propertyControls: PropertyControls = {
        offset: { type: ControlType.Number, min: 0, max: 500, title: "Offset" },
    }

    // componentDidMount() {
    //     // console.log(this.props.offset);
    //     app.offset = this.props.offset;
    // }

    // componentWillReceiveProps(props: Props) {
    //     if (props !== this.props) {
    //         app.offset = this.props.offset;
    //     }
    // }


    // componentWillReceiveProps(props: Props) {
    //     if (app.isFixed) {
    //         this.setState({ isFixed: true });
    //     } else {
    //         this.setState({ isFixed: false });
    //     }
        // console.log(this.props);
        // console.log(this.props.offset)
        // if (app.is)

        // console.log(app.scrollPosition);
    // }

    // private toggleFixed(): React.CSSProperties {
    //     return this.state.isFixed ? {
    //         top: app.scrollPosition - app.elementTopPosition
    //     } : {
    //         top: 0
    //     }
    // }

    render() {
        const style: React.CSSProperties = {
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
        };

        if (this.props.children.length > 0) {
            return (
                <Frame
                    background="transparent"
                    width={this.props.width}
                    height={this.props.height}
                    style={style}
                    //style={this.toggleFixed()}
                >
                    {this.props.children}
                </Frame>
            );
        } else {
            return (
                <div style={noChildrenStyle}>
                    Connect to the frame you want to be sticky ⟶
                </div>
            );
        }
    }
}
