import * as React from "react";
import { PropertyControls, ControlType, Override, Data, Frame } from "framer";

const app = Data({
    scrollPosition: 0,
    lastTop: 0
});

/* Apply stickyElement override to Sticky component (this one) */
export const stickyElement: Override = props => {
    if (!props.top) return;

    let offset = 0;
    if (props.children && props.children[0].props.offset) {
        offset = props.children[0].props.offset;
    }

    if (app.scrollPosition > props.top + offset) {
        if (app.lastTop < props.top) {
            app.lastTop = props.top;
        }

        /* scroll up */
        if (app.scrollPosition < app.lastTop) {
            if (props.top < app.lastTop - props.height) {
                app.lastTop = 0;

                return {
                    top: props.top
                }
            }
        }

        if (props.top < app.lastTop) {
            return {
                top: props.top
            }
        } else {
            return {
                top: app.scrollPosition
            }
        }
    }
};

/* Apply scrollComponent override to Scroll component (from FramerX) */
export const scrollComponent: Override = props => {
    return {
        onMove: point => {
            app.scrollPosition = -point.y;
        }
    };
};

const initialStyle: React.CSSProperties = {
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    color: "#8855FF",
    background: "rgba(136, 85, 255, 0.1)",
    overflow: "hidden",
    fontSize: 12
};

interface Props {
    offset: number;
}

export class Sticky extends React.Component<Props> {
    state = {
        isFixed: false
    }

    static defaultProps = {
        offset: 0
    }

    static propertyControls: PropertyControls = {
        offset: { type: ControlType.Number, min: 0, max: 500, title: "Offset" }
    }

    render() {
        const style: React.CSSProperties = {
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
        };

        if (this.props.children.length > 0) {
            return (
                <Frame
                    background="transparent"
                    width={this.props.width}
                    height={this.props.height}
                    style={style}
                >
                    {this.props.children}
                </Frame>
            );
        } else {
            return (
                <div style={initialStyle}>
                    Connect to the frame you want to be sticky ⟶
                </div>
            );
        }
    }
}
