import * as React from "react";
import {
  Animatable,
  animate,
  Draggable,
  Frame,
  PropertyControls,
  ControlType
} from "framer";

const emptyStyle: React.CSSProperties = {
  height: "100%",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  textAlign: "center",
  background: "rgba(136, 85, 255, 0.25)",
  overflow: "hidden",
  zIndex: -1
};

const titleStyle: React.CSSProperties = {
  fontWeight: 400,
  lineHeight: "1.8em",
  color: "#8855FF",
  margin: 0,
  padding: 0
};

const paragraphStyle: React.CSSProperties = {
  fontWeight: 600,
  color: "#8855FF",
  margin: 0,
  padding: 0
};

const eventsOff: React.CSSProperties = {
  pointerEvents: "none",
  userSelect: "none"
};

const eventsOn: React.CSSProperties = {
  pointerEvents: "all",
  userSelect: "none"
};

interface Props {
  initialPosition: string;
  bottom: number;
  top: number;
  dimColor: string;
  height: number;
  width: number;
}

interface State {
  constraints: object;
  position: string;
  initialOpacity: any;
  initialTop: number;
  limitTop: number;
  limitBottom: number;
}

let sheetStates;

const basicSheetStates = {
  Top: "top",
  Bottom: "bottom"
};

sheetStates = basicSheetStates;

let sheetStatesNames = Object.keys(sheetStates);
let sheetStatesValues = sheetStatesNames.map(title => sheetStates[title]);

// This function is based on Utils.modulate() of former Framer library
// https://github.com/koenbok/Framer/blob/76e96eb878b22ba6a4b7172ba0219be3df1ffda3/framer/Utils.coffee#L636
const modulateOpacity = (value, rangeA, rangeB, limit = false) => {
  let fromHigh, fromLow, result, toHigh, toLow;

  (fromLow = rangeA[0]), (fromHigh = rangeA[1]);
  (toLow = rangeB[0]), (toHigh = rangeB[1]);
  result =
    toLow + ((value - fromLow) / (fromHigh - fromLow)) * (toHigh - toLow);
  if (limit === true) {
    if (toLow < toHigh) {
      if (result < toLow) {
        return toLow;
      }
      if (result > toHigh) {
        return toHigh;
      }
    } else {
      if (result > toLow) {
        return toLow;
      }
      if (result < toHigh) {
        return toHigh;
      }
    }
  }
  return result;
};

export class BottomSheet extends React.Component<Props, State> {
  static defaultProps: Partial<Props> = {
    initialPosition: sheetStates.Top,
    top: 500,
    bottom: 100,
    dimColor: "rgba(0,0,0, 0.4)",
    height: 667,
    width: 375
  };
  static propertyControls: PropertyControls<Props> = {
    initialPosition: {
      type: ControlType.Enum,
      options: sheetStatesValues,
      optionTitles: sheetStatesNames,
      title: "Start at"
    },
    dimColor: {
      type: ControlType.Color,
      title: "Dim Color"
    },
    top: {
      type: ControlType.Number,
      min: 0,
      max: 1440,
      title: "Top"
    },
    bottom: {
      type: ControlType.Number,
      min: 0,
      max: 1440,
      title: "Bottom"
    }
  };

  state: State = {
    constraints: null,
    position: BottomSheet.defaultProps.initialPosition,
    initialOpacity: 1,
    initialTop: 0,
    limitTop: 0,
    limitBottom: 0
  };

  aTop = Animatable(0);
  dimOpacity = Animatable(1);
  dimMaxOpacity = 1;
  isAnimating = false;
  tolerance = 56;
  animation = null;

  UNSAFE_componentWillMount() {
    let newState = this.getStateDimensions(this.props);
    this.setTopOpacityState(newState);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      let newState = this.getStateDimensions(nextProps);
      this.setTopOpacityState(newState);
    }
  }

  componentDidMount() {
    let newState = this.getStateDimensions(this.props);
    this.setTopOpacityState(newState);

    if (this.refs.bottomSheet) {
      const parent = this.refs.bottomSheet.parentNode;
      parent.style.pointerEvents = "none";
      parent.style.overflow = "hidden";
    }
  }

  componentDidUpdate(prevProps) {
    if (
      this.props !== prevProps ||
      (this.props.children != prevProps.children &&
        this.props.children.length == 1)
    ) {
      let newState = this.getStateDimensions(this.props);
      this.setTopOpacityState(newState);
    }
  }

  setTopOpacityState(state) {
    this.setTop(state.initialTop);
    this.setOpacity(state.initialOpacity);
    this.setState(state);
  }

  getStateDimensions = props => {
    const { height, width, bottom, top, initialPosition } = props;
    const maxTop = height - top;
    const maxBottom = height + top - bottom;
    const constraints = { x: 0, y: maxTop, width, height: maxBottom };
    const limitBottom = height - bottom;
    const limitTop = height - top;

    let position = initialPosition;
    let initialTop =
      initialPosition == sheetStates.Bottom ? limitBottom : limitTop;
    let initialOpacity =
      initialPosition == sheetStates.Bottom ? "0" : this.dimMaxOpacity;
    return {
      position,
      constraints,
      initialOpacity,
      initialTop,
      limitTop,
      limitBottom
    };
  };

  setTop = value => {
    this.aTop.set(value);
  };

  setOpacity = value => {
    this.dimOpacity.set(value);
  };

  getNewPosition = currentTop => {
    let bottomDiff = Math.abs(currentTop - this.state.limitBottom);
    let topDiff = Math.abs(currentTop - this.state.limitTop);

    if (currentTop <= this.state.limitTop) {
      return { position: sheetStates.Top, top: this.state.limitTop };
    }

    if (currentTop >= this.state.limitBottom) {
      return { position: sheetStates.Bottom, top: this.state.limitBottom };
    }

    if (bottomDiff > this.tolerance && this.state.position != sheetStates.Top) {
      return { position: sheetStates.Top, top: this.state.limitTop };
    }

    if (topDiff > this.tolerance && this.state.position != sheetStates.Bottom) {
      return { position: sheetStates.Bottom, top: this.state.limitBottom };
    }

    let position = bottomDiff >= topDiff ? sheetStates.Top : sheetStates.Bottom;
    let top =
      position == sheetStates.Bottom
        ? this.state.limitBottom
        : this.state.limitTop;
    return { position, top };
  };

  onMoveHandler = () => {
    if (this.animation) {
      this.animation.finish();
      this.animation = null;
    }
    const dimOpacity = modulateOpacity(
      this.aTop.get(),
      [this.state.limitBottom, this.state.limitTop],
      [0, this.dimMaxOpacity]
    );
    this.setOpacity(dimOpacity);
  };

  dragEndHandler = async () => {
    if (this.isAnimating) {
      return;
    } else {
      this.isAnimating = true;
      const newPosition = this.getNewPosition(this.aTop.get());
      const dimOpacity =
        newPosition.position == sheetStates.Bottom ? 0 : this.dimMaxOpacity;
      this.animation = animate.spring(this.aTop, newPosition.top, {
        duration: 0.35
      });
      console.log(this.animation.finished);
      await animate.linear(this.dimOpacity, dimOpacity, { duration: 0.3 })
        .finished;
      this.setState({ position: newPosition.position });
      this.isAnimating = false;
    }
  };

  dragAnimationEndHandler = () => {
    let position = sheetStates.Bottom;
    if (this.aTop.get() == this.state.limitTop) {
      position = sheetStates.Top;
    }
    this.isAnimating = false;
    this.setState({ position });
  };

  tapHandler = async () => {
    if (this.state.position == sheetStates.Top && !this.isAnimating) {
      this.isAnimating = true;
      animate.linear(this.dimOpacity, 0, { duration: 0.35 });
      await animate.spring(this.aTop, this.state.limitBottom, {
        duration: 0.45
      }).finish;
      this.setState({ position: sheetStates.Bottom });
      this.isAnimating = false;
    }
  };

  render() {
    if (this.props.children.length != 1) {
      const title = <h2 style={titleStyle}>{"Bottom Sheet"}</h2>;
      const content = (
        <p style={paragraphStyle}>{"connect to frame content →"}</p>
      );
      return (
        <div style={emptyStyle}>
          {title}
          {content}
        </div>
      );
    }
    const { width, height, dimColor, children } = this.props;
    const { constraints, position } = this.state;

    return (
      <div style={eventsOff} ref="bottomSheet">
        <Frame
          onTap={this.tapHandler}
          width={width}
          height={height}
          background={dimColor}
          opacity={this.dimOpacity}
          style={position == sheetStates.Bottom ? eventsOff : eventsOn}
        />
        <Draggable
          onDragAnimationEnd={this.dragAnimationEndHandler}
          onDragEnd={this.dragEndHandler}
          onMove={this.onMoveHandler}
          constraints={constraints}
          bounce
          overdrag
          width={width}
          height={height}
          background={null}
          horizontal={false}
          momentum={false}
          top={this.aTop}
          style={eventsOn}
        >
          {children}
        </Draggable>
      </div>
    );
  }
}

export class BottomSheetScroll extends React.Component<Props, State> {
  aTop = Animatable(0);
  sTop = Animatable(0);
  dimOpacity = Animatable(1);
  dimMaxOpacity = 1;
  isAnimating = false;
  tolerance = 56;
  animation = null;

  static defaultProps: Partial<Props> = {
    initialPosition: sheetStates.Top,
    top: 550,
    bottom: 100,
    dimColor: "rgba(0,0,0, 0.4)",
    height: 667,
    width: 375
  };
  static propertyControls: PropertyControls<Props> = {
    initialPosition: {
      type: ControlType.Enum,
      options: sheetStatesValues,
      optionTitles: sheetStatesNames,
      title: "Start at"
    },
    dimColor: {
      type: ControlType.Color,
      title: "Dim Color"
    },
    top: {
      type: ControlType.Number,
      min: 0,
      max: 1440,
      title: "Top"
    },
    bottom: {
      type: ControlType.Number,
      min: 0,
      max: 1440,
      title: "Bottom"
    }
  };

  state: State = {
    constraints: null,
    position: BottomSheet.defaultProps.initialPosition,
    initialOpacity: 1,
    initialTop: 0,
    limitTop: 0,
    limitBottom: 0,
  };

  UNSAFE_componentWillMount() {
    let newState = this.getStateDimensions(this.props);
    this.setTopOpacityState(newState);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      let newState = this.getStateDimensions(nextProps);
      this.setTopOpacityState(newState);
    }
  }

  componentDidMount() {
    let newState = this.getStateDimensions(this.props);
    this.setTopOpacityState(newState);

    if (this.refs.bottomSheet) {
      const parent = this.refs.bottomSheet.parentNode;
      parent.style.pointerEvents = "none";
      parent.style.overflow = "hidden";
    }
  }

  componentDidUpdate(prevProps) {
    if (
      this.props !== prevProps ||
      (this.props.children != prevProps.children &&
        this.props.children.length == 1)
    ) {
      let newState = this.getStateDimensions(this.props);
      this.setTopOpacityState(newState);
    }
  }

  setTopOpacityState(state) {
    this.setTop(state.initialTop);
    this.setOpacity(state.initialOpacity);
    this.setState(state);
  }

  getStateDimensions = props => {
    const { height, width, bottom, top, initialPosition } = props;
    const maxTop = height - top;
    const maxBottom = height + top - bottom;
    const constraints = { x: 0, y: maxTop, width, height: maxBottom };
    const limitBottom = height - bottom;
    const limitTop = height - top;

    let position = initialPosition;
    let initialTop = initialPosition == sheetStates.Bottom ? limitBottom : limitTop;
    let initialOpacity = initialPosition == sheetStates.Bottom ? "0" : this.dimMaxOpacity;
    return {
      position,
      constraints,
      initialOpacity,
      initialTop,
      limitTop,
      limitBottom
    };
  };

  setTop = value => {
    this.aTop.set(value);
  };

  setOpacity = value => {
    this.dimOpacity.set(value);
  };

  getNewPosition = currentTop => {
    let bottomDiff = Math.abs(currentTop - this.state.limitBottom);
    let topDiff = Math.abs(currentTop - this.state.limitTop);

    if (currentTop <= this.state.limitTop) {
      return { position: sheetStates.Top, top: this.state.limitTop };
    }

    if (currentTop >= this.state.limitBottom) {
      return { position: sheetStates.Bottom, top: this.state.limitBottom };
    }

    if (bottomDiff > this.tolerance && this.state.position != sheetStates.Top) {
      return { position: sheetStates.Top, top: this.state.limitTop };
    }

    if (topDiff > this.tolerance && this.state.position != sheetStates.Bottom) {
      return { position: sheetStates.Bottom, top: this.state.limitBottom };
    }

    let position = bottomDiff >= topDiff ? sheetStates.Top : sheetStates.Bottom;
    let top =
      position == sheetStates.Bottom
        ? this.state.limitBottom
        : this.state.limitTop;
    return { position, top };
  };

  onMoveHandler = () => {
    if (this.animation) {
      this.animation.finish();
      this.animation = null;
    }
    const dimOpacity = modulateOpacity(
      this.aTop.get(),
      [this.state.limitBottom, this.state.limitTop],
      [0, this.dimMaxOpacity]
    );
    this.setOpacity(dimOpacity);
  };

  scrollDragEnd = (e, f) => {
    const newPosition = this.getNewPosition(this.aTop.get());
    if(newPosition.position == sheetStates.Bottom) {
      f.stopAnimation();
      animate.spring(this.sTop, 0, { duration: 0.25});
    }
  }

  dragEndHandler = async () => {
    if (this.isAnimating) {
      return;
    } else {
      this.isAnimating = true;
      const newPosition = this.getNewPosition(this.aTop.get());
      const dimOpacity = newPosition.position == sheetStates.Bottom ? 0 : this.dimMaxOpacity;

      this.animation = animate.spring(this.aTop, newPosition.top, {
        duration: 0.35
      });
      await animate.linear(this.dimOpacity, dimOpacity, { duration: 0.3 })
        .finished;
      this.setState({ position: newPosition.position });
      this.isAnimating = false;
    }
  };

  dragAnimationEndHandler = () => {
    let position = sheetStates.Bottom;
    if (this.aTop.get() == this.state.limitTop) {
      position = sheetStates.Top;
    }
    this.isAnimating = false;
    this.setState({ position });
  };

  tapHandler = async () => {
    if (this.state.position == sheetStates.Top && !this.isAnimating) {
      this.isAnimating = true;
      animate.linear(this.dimOpacity, 0, { duration: 0.35 });
      animate.spring(this.sTop, 0, { duration: 0.2});
      await animate.spring(this.aTop, this.state.limitBottom, {
        duration: 0.45
      }).finish;
      this.setState({ position: sheetStates.Bottom });
      this.isAnimating = false;
    }
  };


  render() {
    if (this.props.children.length != 1) {
      const title = <h2 style={titleStyle}>{"Bottom Sheet Scroll"}</h2>;
      const content = (
        <p style={paragraphStyle}>
          {"connect to frame content →"}
          <br />
          {"use mouse wheel or two fingers"}
          <br />
          {"on trackpad to scroll"}
        </p>
      );
      return (
        <div style={emptyStyle}>
          {title}
          {content}
        </div>
      );
    }
    const { width, height, dimColor, children } = this.props;
    const { constraints, position } = this.state;

    return (
      <div style={eventsOff} ref="bottomSheet">
        <Frame
          onTap={this.tapHandler}
          width={width}
          height={height}
          background={dimColor}
          opacity={this.dimOpacity}
          style={position == sheetStates.Bottom ? eventsOff : eventsOn}
        />
        <Draggable
          onDragAnimationEnd={this.dragAnimationEndHandler}
          onDragEnd={this.dragEndHandler}
          onMove={this.onMoveHandler}
          constraints={constraints}
          bounce
          overdrag={false}
          width={width}
          height={height}
          background={null}
          horizontal={false}
          momentum={false}
          top={this.aTop}
          style={eventsOn}
          overflow={"hidden"}
          dropShadows={[{ color: 'rgba(0, 0, 0, 0.08)', x: 0, y: 0, blur: 3 }]}
          radius={children[0].props.radius}
          >
          <Draggable
            onDragEnd={this.scrollDragEnd}
            ref="bottomSheetScroll"
            bounce
            momentum
            mouseWheel
            horizontal={false}
            overdrag={false}
            background={null}
            style={position == sheetStates.Bottom ? eventsOff : eventsOn}
            width={width}
            height={children[0].props.height}
            constraints={{ x: 0, y: this.props.top - children[0].props.height, width, height: children[0].props.height*2 - this.props.top}}
            top={this.sTop}
          >
            {children}
          </Draggable>
        </Draggable>
      </div>
    );
  }
}
